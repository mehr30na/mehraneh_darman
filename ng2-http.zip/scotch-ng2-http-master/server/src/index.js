import Server from './server';
var server = new Server();
server.run();