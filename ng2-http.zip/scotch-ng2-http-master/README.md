## Scotch HTTP NG2


### To start server
```bash
cd server
npm install
npm start
```

### To start client
```bash
cd client
npm install
npm start
```