## Client
Clone and run:

```bash
npm install
npm start
```